sap.ui.define(["sap/ui/core/mvc/Controller", "sap/m/MessageToast", "sap/ui/model/json/JSONModel"], function (Controller, MessageToast, JSONModel) {
  "use strict";

  const AppController = Controller.extend("ui5.tutorial.quickstart.AppController", {
    onPress() {
      MessageToast.show("Hello UI5!");
      this.byId("app").to(this.byId("intro"));
    },
    onInit() {
      this.getView().setModel(new JSONModel({
        features: ["Enterprise-Ready Web Toolkit", "Powerful Development Concepts", "Feature-Rich UI Controls", "Consistent User Experience", "Free and Open Source", "Responsive Across Browsers and Devices"]
      }));
    },
    onChange(event) {
      const state = event.getParameter("state");
      this.byId("ready").setVisible(state);
    }
  });
  return AppController;
});
