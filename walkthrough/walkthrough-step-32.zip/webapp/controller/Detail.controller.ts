import Controller from "sap/ui/core/mvc/Controller";
import History from "sap/ui/core/routing/History";
import UIComponent from "sap/ui/core/UIComponent";
import Route, { Route$PatternMatchedEvent } from "sap/ui/core/routing/Route";

/**
 * @namespace ui5.tutorial.walkthrough.controller
 */
export default class Detail extends Controller {

	onInit(): void {
		const router = UIComponent.getRouterFor(this);
		(router.getRoute("detail") as Route).attachPatternMatched(this.onObjectMatched, this);
	}

	onObjectMatched(event: Route$PatternMatchedEvent): void {
		this.getView()?.bindElement({
			path: "/" + window.decodeURIComponent( (event.getParameter("arguments") as any).invoicePath),
			model: "invoice"
		});
	}

	onNavBack(): void {
		const history = History.getInstance();
		const previousHash = history.getPreviousHash();

		if (previousHash !== undefined) {
			window.history.go(-1);
		} else {
			const router = UIComponent.getRouterFor(this);
			router.navTo("overview", {}, true);
		}
	}
};
